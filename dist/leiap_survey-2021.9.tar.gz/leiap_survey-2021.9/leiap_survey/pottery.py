# imports
import pandas as pd
import leiap_survey.temporal as tmp
from tqdm.notebook import tqdm

''' Pottery functions'''
name = 'pottery'


def select_productions(ti_tbl, name='Abbrev', criteria={'ti1_min_overlap': 50},
                       opt=None):
    '''
    selects productions based on criteria

    Parameters
    ----------
    ti_tbl: pandas dataframe
        contains the results of the `generate_temporal_intersection_table()`
        function
    name: string
        name of the column holding ceramic production names
    criteria: dictionary
        contains criteria for ceramic production selection. Critera may be
        specify via the following entries:
        -'ti_overlap': minimum amount of temporal interval overlap. Ceramic
          productions with this or greater overlap will be selected
        -'prod_overlap':  minimum amount of ceramic production overlap. Ceramic
          productions with this or greater overlap will be selected
        -'gap:': minimum amount of gap. Ceramic productions with this or
          greater amount of gap will be selected
        -'itype': a list containing the type of intersections to be selected
         (see `calculate_temporal_intersection()`)

    opt: string
        Use 'table' to generate table output. Leave blank to return only names
        of ceramic productions (default)

    Result
    ------
        pandas dataframe
            Table with names of diagnostic ceramic productions
    '''

    # process criteria text
    if 'ti1_min_overlap' in criteria.keys():
        qury = "ti1_overlap >= @criteria['ti1_min_overlap']"
    else:
        print('\n ERROR: Need ti_overlap!')
        return None

    if 'ti2_min_overlap' in criteria.keys():
        qury += " and ti2_overlap >= @criteria['ti2_min_overlap']"

    if 'gap' in criteria.keys():
        qury += " and gap >= @criteria['gap']"

    if 'itype' in criteria.keys():
        qury += " and itype in @criteria['itype']"

    # select by criteria
    tbl = (ti_tbl.query(qury)
                 .sort_values(['ti1_overlap', 'ti2_overlap', 'gap', 'itype'],
                              ascending=False))

    if opt == 'table':
        return tbl
    else:
        return tbl[name].tolist()


def production_diagnostic_scoring(prod_df, ti, criteria_lst,
                                  prod_kw={'start': 'Start',
                                           'end': 'End',
                                           'name': 'Abbrev'}):
    '''
    generates a table with a diagnostic scoring for each ceramic production in
    a table based on different temporal overlap criteria

    Parameters
    ----------
    prod_df: pandas dataframe
        contains columns with chronological information (start, end) and name
        (name) of ceramic productions
    ti: dictionary
        time interval defined by two entries 'start' and 'end'(BCE are entered
        as negative values)
    criteria_lst: list
        each entry is a dictionary containing temporal criteria. Critera may be
        specify via the following entries:
            -'ti_overlap': minimum amount of temporal interval overlap. Ceramic
              productions with this or greater overlap will be selected
            -'prod_overlap':  minimum amount of ceramic production overlap.
              Ceramic productions with this or greater overlap will be selected
            -'gap:': minimum amount of gap. Ceramic productions with this or
              greater amount of gap will be selected
            -'itype': a list containing the type of intersections to be
             selected (see `calculate_temporal_intersection()`)
    prod_kw: dictionary
        contains entries (start, end and name) used to identify columns in
        prod_df with chronological information (start, end) and production
        names

    Result
    ------
    score_tbl: pandas dataframe
        contains ceramic productions with the count the times that they have
        been selected and a diagnostic score based on the frequency

    '''

    # helper function to update scores of ceramic productions
    def _update_score(score, sel):
        for k in sel:
            if k in score.keys():
                score[k] = score[k]+1
            else:
                # initialize when ceramic production is new
                score[k] = 1
        return score

    # iterate over criteria
    score = {}
    for c in tqdm(criteria_lst, desc='scoring...'):

        # generate temporal intersection table
        ti_tbl = tmp.generate_temporal_intersection_table(ti, prod_df, prod_kw)

        # select productions that meet criteria
        sel = select_productions(ti_tbl, name=prod_kw['name'], criteria=c)

        # update score
        score = _update_score(score, sel)

    # create table with counts and score
    score_tbl = (pd.DataFrame({'production': score.keys(), 'num': score.values()})
                   .assign(score_rel=lambda x: x.num/x.num.max())
                   .assign(score_max=lambda x: x.num/len(criteria_lst))
                   .sort_values(['score_rel', 'score_max'], ascending=False)
                   .reset_index(drop=True))

    return score_tbl
